package shoppingcart;


public enum ActionType {
    ADD,
    REMOVE,
    PRINT
}
