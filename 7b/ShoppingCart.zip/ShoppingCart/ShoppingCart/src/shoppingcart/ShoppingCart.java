package shoppingcart;

import products.Product;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ShoppingCart {
	private List<CartLine> cartLines = new ArrayList<>();

	public enum ActionType { ADD, REMOVE, PRINT }

	public void processAction(Product product, ActionType action) {
		switch (action) {
			case ADD:
				addProduct(product);
				break;
			case REMOVE:
				removeProduct(product);
				break;
			case PRINT:
				printCart();
				break;
		}
	}

	private void addProduct(Product product) {
		for (CartLine line : cartLines) {
			if (line.getProduct().getProductNumber().equals(product.getProductNumber())) {
				line.setQuantity(line.getQuantity() + 1);
				return;
			}
		}
		cartLines.add(new CartLine(product, 1));
	}

	private void removeProduct(Product product) {
		Iterator<CartLine> iterator = cartLines.iterator();
		while (iterator.hasNext()) {
			CartLine line = iterator.next();
			if (line.getProduct().getProductNumber().equals(product.getProductNumber())) {
				if (line.getQuantity() > 1) {
					line.setQuantity(line.getQuantity() - 1);
				} else {
					iterator.remove();
				}
			}
		}
	}

	private void printCart() {
		System.out.println("Shopping Cart:");
		for (CartLine line : cartLines) {
			System.out.println(line);
		}
		System.out.println("Total Price: $" + calculateTotal());
	}

	public double calculateTotal() {
		return cartLines.stream()
				.mapToDouble(line -> line.getProduct().getPrice() * line.getQuantity())
				.sum();
	}
}
