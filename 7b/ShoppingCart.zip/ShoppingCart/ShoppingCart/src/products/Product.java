package products;
public class Product {
	private String productNumber;
	private double price;
	private String description;

	public Product(String productNumber, double price, String description) {
		if (productNumber == null || productNumber.isEmpty()) {
			throw new IllegalArgumentException("Product number cannot be null or empty.");
		}
		if (price < 0) {
			throw new IllegalArgumentException("Price cannot be negative.");
		}
		this.productNumber = productNumber;
		this.price = price;
		this.description = description;
	}


	public String getproductNumber() {
		return productNumber;
	}

	public void setproductNumber(String productNumber) {
		this.productNumber = productNumber;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {

		if (price < 0) {
			throw new IllegalArgumentException("Price cannot be negative.");
		}
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {

		this.description = description;

	}

}
