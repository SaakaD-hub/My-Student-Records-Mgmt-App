package application;
import products.Product;
import shoppingcart.ShoppingCart;


public class Application {
	public static void main(String[] args) {
		ShoppingCart cart = new ShoppingCart();

		Product tv = new Product("A123", 100.0, "TV");
		Product mp3Player = new Product("A665", 75.0, "MP3 Player");

		cart.processAction(tv, ActionType.ADD);
		cart.processAction(mp3Player, ActionType.ADD);
		cart.processAction(mp3Player, ActionType.ADD);
		cart.processAction(null, ActionType.PRINT);

		cart.processAction(mp3Player, ActionType.REMOVE);
		cart.processAction(tv, ActionType.REMOVE);
		cart.processAction(null, ActionType.PRINT);
	}

}
